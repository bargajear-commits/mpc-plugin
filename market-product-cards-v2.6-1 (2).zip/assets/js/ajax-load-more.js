jQuery(function($){
    $(document).on('click', '#mpc-load-more-btn', function(e){
        e.preventDefault();

        var $button = $(this);
        var currentPage = parseInt($button.attr('data-current-page'), 10);
        var maxPages = parseInt($button.attr('data-max-pages'), 10);
        
        // --- 1. Get Current Filters ---
        var queryVarsString = $button.attr('data-query-vars');
        var queryVars = {};
        if (queryVarsString) {
             try {
                // Decode HTML entities before parsing JSON (necessary for security reasons in PHP)
                queryVars = JSON.parse($('<div/>').html(queryVarsString).text());
             } catch (e) {
                console.error("Error parsing data-query-vars:", e);
                // Fallback to reading from hidden category field if available
                var currentCat = $('#mpc-current-cat').val(); 
                if (currentCat) queryVars.product_cat = currentCat;
             }
        }
        
        var newPage = currentPage + 1;

        // --- 2. Build AJAX Data ---
        var data = $.extend(queryVars, {
            action: 'mpc_filter_products', // Use the same handler as filtering
            nonce: mpc_ajax.nonce, // FIX: Use the localized nonce (mpc_filters_nonce)
            page: newPage, // Pass the next page number
        });

        $button.text('Loading...').prop('disabled', true);

        // --- 3. Send AJAX Request ---
        $.post(mpc_ajax.ajax_url, data, function(resp){
            if (resp.success && resp.data.html) {
                
                // --- 4. Process Response ---
                // Wrap the response in a div to query it
                var $responseContainer = $('<div>').html(resp.data.html); 
                
                // The response contains the new products and possibly a new load more button
                var $newCards = $responseContainer.find('.mpc-card');
                var $newButton = $responseContainer.find('#mpc-load-more-btn');
                
                // Append the new product cards to the main grid
                $('#mpc-grid').append($newCards);
                
                // --- 5. Update Button State ---
                $button.attr('data-current-page', newPage);

                if (newPage < maxPages && $newButton.length) {
                    // Update button with the new button's data (new query vars for next page) and re-enable
                    $button.attr('data-query-vars', $newButton.attr('data-query-vars'));
                    $button.text('Load More').prop('disabled', false);
                } else {
                    // All pages loaded, hide the button
                    $button.parent().remove(); // Remove the wrapper div
                }

                // FIX: Re-initialize Elementor or other responsive logic if available
                if (typeof elementorFrontend !== 'undefined') {
                     elementorFrontend.elements.$window.trigger('resize');
                }
            } else {
                $button.text('Error loading products').prop('disabled', false);
                console.error('Load More Error:', resp);
            }
        }, 'json').fail(function() {
             $button.text('Network Error').prop('disabled', false);
        });
    });
});