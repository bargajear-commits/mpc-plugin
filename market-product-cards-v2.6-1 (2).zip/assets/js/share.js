jQuery(function($){
    var modal = $('#mpc-share-modal');
    // Function to open the modal and set share links
    function openModal(link){
        modal.attr('aria-hidden','false').data('link', link);
        modal.find('.mpc-share-whatsapp').attr('href', 'https://wa.me/?text=' + encodeURIComponent(link));
        modal.find('.mpc-share-facebook').attr('href', 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(link));
        modal.find('.mpc-share-x').attr('href', 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(link));
    }
    // Function to close the modal
    function closeModal(){ modal.attr('aria-hidden','true').data('link',''); }

    // Event listener for opening the modal via the trigger button on product cards
    $(document).on('click', '.mpc-share-trigger', function(e){
        e.preventDefault();
        var link = $(this).data('link') || $(this).closest('.mpc-card').data('link');
        openModal(link);
    });
    
    // Removed: Event listener for .mpc-share-close button as requested.
    
    // Listen for clicks on the modal overlay itself to close it (Click Outside logic)
    // The conditional check (e.target === this) ensures only clicks on the background/overlay close the modal, not clicks inside the inner content.
    modal.on('click', function(e){
        if (e.target === this) closeModal();
    });

    // Event listener for copying the link
    modal.on('click', '.mpc-share-copy', function(){
        var link = modal.data('link') || '';
        if (!link) return;
        
        // Use document.execCommand('copy') for better compatibility inside iframes/Canvas
        var tempInput = $('<input>');
        $('body').append(tempInput);
        tempInput.val(link).select();
        document.execCommand('copy');
        tempInput.remove();

        // Show "Copied!" message for a brief period (Replaces disallowed alert())
        var $btn = $(this);
        var originalText = $btn.text();
        $btn.text('Copied!');
        setTimeout(function() {
            $btn.text(originalText);
        }, 1500);
    });
});
