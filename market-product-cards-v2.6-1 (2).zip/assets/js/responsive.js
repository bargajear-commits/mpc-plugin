jQuery(function($){
    function applyColumns($grid){
        var desktop = parseInt($grid.attr('data-desktop') || 4, 10);
        var tablet = parseInt($grid.attr('data-tablet') || 2, 10);
        var mobile = parseInt($grid.attr('data-mobile') || 1, 10);
        var w = $(window).width();
        var cols = desktop;
        // Logic to apply 1 column on mobile (w <= 600)
        if (w <= 600) cols = mobile;
        else if (w <= 1024) cols = tablet;
        $grid.css('grid-template-columns', 'repeat(' + cols + ', 1fr)');
    }
    
    // Main function to initialize/re-initialize responsive columns
    function init(){
        $('.mpc-grid').each(function(){
            var $g = $(this);
            // Apply columns immediately
            applyColumns($g);
            
            // Re-attach resize listener only if it hasn't been attached to this element
            if (!$g.data('mpc-resize-listener')) {
                // Use a unique ID based on a random number for namespaced resize events
                var resizeId = 'mpc-resize-' + Math.random().toString(36).substring(2, 9);
                $g.data('mpc-resize-listener', resizeId);

                $(window).on('resize.' + resizeId, function(){ 
                    applyColumns($g); 
                });
            }
        });
    }

    // --- UPDATED FIX: Expose the init function for AJAX re-initialization ---
    // This is the function called by the filter scripts to fix the 4-column issue.
    window.mpcReInitGrid = init;
    // --- END UPDATED FIX ---

    init();
    // re-init on document ready mutations (Elementor preview)
    $(document).on('elementor/frontend/init', function(){ init(); });
});