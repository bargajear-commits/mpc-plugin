(function($){
    // Top filter bar interactions
    function collectTopFilters(){
        var data = {};
        var kw = $('#mpc-search-keyword').val();
        var min = $('#mpc-top-min-price').val();
        var max = $('#mpc-top-max-price').val();
        
        // NEW: Get current category from hidden field if present (for archive page filtering)
        var currentCat = $('#mpc-current-cat').val(); 

        if (kw) data.s = kw;
        if (min) data.min_price = min;
        if (max) data.max_price = max;
        // NEW: Include current category in AJAX data if found
        if (currentCat) data.product_cat = currentCat;
        
        data.action = 'mpc_filter_products';
        data.nonce = mpc_filter_bar_obj.nonce || mpc_filters_obj.nonce;
        data.per_page = $('#mpc-grid').data('per-page') || 12;
        return data;
    }

    $(document).on('click', '#mpc-top-apply', function(e){
        e.preventDefault();
        var data = collectTopFilters();
        // update URL params for shareable links (use readable keys)
        var params = [];
        if (data.s) params.push('s=' + encodeURIComponent(data.s));
        if (data.min_price) params.push('min_price=' + encodeURIComponent(data.min_price));
        if (data.max_price) params.push('max_price=' + encodeURIComponent(data.max_price));
        var newUrl = window.location.protocol + '//' + window.location.host + window.location.pathname + (params.length ? '?' + params.join('&') : '');
        history.replaceState(null, '', newUrl);

        $.post(mpc_filter_bar_obj.ajax_url, data, function(resp){
            if (resp.success && resp.data.html) {
                $('#mpc-product-container').html(resp.data.html);
                // scroll to results neatly
                $('html,body').animate({scrollTop: $('#mpc-product-container').offset().top - 80}, 300);
                // --- ADDED FIX: Call responsive function after loading new content ---
                if (window.mpcReInitGrid) window.mpcReInitGrid();
                // --- END ADDED FIX ---
            }
        }, 'json');
    });

    $(document).on('click', '#mpc-top-reset', function(e){
        e.preventDefault();
        $('#mpc-search-keyword').val('');
        $('#mpc-top-min-price').val('');
        $('#mpc-top-max-price').val('');
        history.replaceState(null, '', window.location.pathname);
        // trigger apply to reload default set
        $('#mpc-top-apply').click();
    });

    // trigger apply when user presses Enter in search
    $(document).on('keydown', '#mpc-search-keyword', function(e){
        if (e.key === 'Enter') {
            e.preventDefault();
            $('#mpc-top-apply').click();
        }
    });

    // On page load, if URL contains relevant params and there's no lower filter present, sync inputs (fallback to previous mpc-filters behavior)
    $(document).ready(function(){
        var qs = new URLSearchParams(window.location.search);
        var filters_present = false;
        if (qs.has('s')) {
            $('#mpc-search-keyword').val(qs.get('s'));
            filters_present = true;
        }
        if (qs.has('min_price')) {
            $('#mpc-top-min-price').val(qs.get('min_price'));
            filters_present = true;
        }
        if (qs.has('max_price')) {
            $('#mpc-top-max-price').val(qs.get('max_price'));
            filters_present = true;
        }
        // if any top-bar params present, apply them automatically
        if (filters_present) {
            $('#mpc-top-apply').click();
        }
    });
})(jQuery);