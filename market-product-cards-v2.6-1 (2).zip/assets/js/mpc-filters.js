(function($){
    // Simple filter JS: collects form data, updates URL, sends AJAX to fetch products and replace grid
    function collectFilters() {
        var data = {};
        var min = $('#mpc-min-price').val();
        var max = $('#mpc-max-price').val();
        
        // NEW: Get current category from hidden field if present (for archive page filtering)
        var currentCat = $('#mpc-current-cat').val(); 
        
        if (min) data.min_price = min;
        if (max) data.max_price = max;
        // NEW: Include current category in AJAX data if found
        if (currentCat) data.product_cat = currentCat;

        data.per_page = $('#mpc-grid').data('per-page') || 12;
        return data;
    }

    window.mpcApplyFiltersFromUrl = function(params) {
        // params is an object of pre-set filters (used by inline PHP when parsing slugs)
        var payload = $.extend({}, params);
        
        // NEW: Ensure current category is included when filters are applied from URL
        var currentCat = $('#mpc-current-cat').val(); 
        if (currentCat) payload.product_cat = currentCat;
        
        payload.action = 'mpc_filter_products';
        payload.nonce = mpc_filters_obj.nonce;
        $.post(mpc_filters_obj.ajax_url, payload, function(resp){
            if (resp.success && resp.data.html) {
                $('#mpc-product-container').html(resp.data.html);
                // --- ADDED FIX: Call responsive function after loading new content ---
                if (window.mpcReInitGrid) window.mpcReInitGrid();
                // --- END ADDED FIX ---
            }
        }, 'json');
    };

    $(document).on('click', '#mpc-apply-filters', function(e){
        e.preventDefault();
        var data = collectFilters();
        data.action = 'mpc_filter_products';
        data.nonce = mpc_filters_obj.nonce;

        // update URL with params
        var params = [];
        if (data.min_price) params.push('min_price=' + encodeURIComponent(data.min_price));
        if (data.max_price) params.push('max_price=' + encodeURIComponent(data.max_price));
        var newUrl = window.location.protocol + '//' + window.location.host + window.location.pathname + (params.length ? '?' + params.join('&') : '');
        history.replaceState(null, '', newUrl);

        $.post(mpc_filters_obj.ajax_url, data, function(resp){
            if (resp.success && resp.data.html) {
                $('#mpc-product-container').html(resp.data.html);
                // --- ADDED FIX: Call responsive function after loading new content ---
                if (window.mpcReInitGrid) window.mpcReInitGrid();
                // --- END ADDED FIX ---
            }
        }, 'json');
    });

    $(document).on('click', '#mpc-clear-filters', function(e){
        e.preventDefault();
        $('#mpc-min-price').val('');
        $('#mpc-max-price').val('');
        history.replaceState(null, '', window.location.pathname);
        // re-load initial set via AJAX or refresh page; here we simply trigger apply to get all products
        $('#mpc-apply-filters').click();
    });

    // On page load, if there are query params present, attempt to apply them
    $(document).ready(function(){
        var qs = new URLSearchParams(window.location.search);
        var data = {};
        if (qs.has('min_price')) {
            $('#mpc-min-price').val(qs.get('min_price'));
            data.min_price = qs.get('min_price');
        }
        if (qs.has('max_price')) {
            $('#mpc-max-price').val(qs.get('max_price'));
            data.max_price = qs.get('max_price');
        }

        // if we have any filter in URL, apply it
        if (Object.keys(data).length > 0) {
            // NEW: Automatically include the current category for filtering on archive pages
            var currentCat = $('#mpc-current-cat').val();
            if (currentCat) data.product_cat = currentCat; 
            
            data.action = 'mpc_filter_products';
            data.nonce = mpc_filters_obj.nonce;
            $.post(mpc_filters_obj.ajax_url, data, function(resp){
                if (resp.success && resp.data.html) {
                    $('#mpc-product-container').html(resp.data.html);
                    // --- ADDED FIX: Call responsive function after loading new content ---
                    if (window.mpcReInitGrid) window.mpcReInitGrid();
                    // --- END ADDED FIX ---
                }
            }, 'json');
        }
    });
})(jQuery);