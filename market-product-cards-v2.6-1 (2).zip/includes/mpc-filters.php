<?php
// MPC Filters - adds AJAX filtering and URL param parsing without changing card design.

if (!defined('ABSPATH')) exit;

/* Enqueue filter assets */
function mpc_filters_enqueue() {
    wp_enqueue_script('mpc-filters-js', MPC_URL . 'assets/js/mpc-filters.js', array('jquery'), '1.0', true);
    wp_localize_script('mpc-filters-js', 'mpc_filters_obj', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('mpc_filters_nonce'),
    ));
    wp_enqueue_style('mpc-style'); // ensure main style loaded
}
add_action('wp_enqueue_scripts', 'mpc_filters_enqueue', 20);

/* Shortcode to render filter UI (keeps product card markup unchanged) */
function mpc_filters_shortcode($atts) {
    ob_start();
    // NEW: Get current category slug from URL if on an archive page
    $current_category = '';
    if (is_product_category()) {
        $queried_object = get_queried_object();
        if ($queried_object && isset($queried_object->slug)) {
            $current_category = $queried_object->slug;
        }
    }
    ?>
    <div id="mpc-filters">
        <form id="mpc-filter-form" onsubmit="return false;">
            <?php if ($current_category): ?>
                <input type="hidden" name="current_product_cat" id="mpc-current-cat" value="<?php echo esc_attr($current_category); ?>" />
            <?php endif; ?>
            <div class="mpc-filter-row">
                <label>Min Price <input type="number" name="min_price" id="mpc-min-price" placeholder="0"></label>
                <label>Max Price <input type="number" name="max_price" id="mpc-max-price" placeholder="10000"></label>
                <button id="mpc-apply-filters" class="button">Apply</button>
                <button id="mpc-clear-filters" class="button">Clear</button>
            </div>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('mpc_filters', 'mpc_filters_shortcode');

/**
 * AJAX handler - returns product cards HTML using existing template
 */
function mpc_ajax_filter_handler() {
    // FIX: Check nonce using the common key 'mpc_filters_nonce'
    check_ajax_referer('mpc_filters_nonce', 'nonce');

    $min_price = isset($_POST['min_price']) ? floatval($_POST['min_price']) : 0;
    $search_kw = isset($_POST['s']) ? sanitize_text_field($_POST['s']) : '';
    $max_price = isset($_POST['max_price']) && $_POST['max_price'] !== '' ? floatval($_POST['max_price']) : 0;
    // UPDATED: Now accepts category slug (string) or term ID (string/int)
    $cat = isset($_POST['product_cat']) ? sanitize_text_field($_POST['product_cat']) : '';
    $paged = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 12;

    // Responsive columns are passed to maintain grid layout on load more
    $desktop_columns = isset($_POST['desktop_columns']) ? intval($_POST['desktop_columns']) : null;
    $tablet_columns = isset($_POST['tablet_columns']) ? intval($_POST['tablet_columns']) : null;
    $mobile_columns = isset($_POST['mobile_columns']) ? intval($_POST['mobile_columns']) : null;


    $meta_query = array();
    
    // --- Price Filtering Logic ---
    if ($min_price > 0 && $max_price > 0 && $min_price <= $max_price) {
        $meta_query[] = array(
            'key' => '_price',
            'value' => array($min_price, $max_price),
            'compare' => 'BETWEEN',
            'type' => 'NUMERIC',
        );
    } elseif ($min_price > 0) {
        $meta_query[] = array(
            'key' => '_price',
            'value' => $min_price,
            'compare' => '>=',
            'type' => 'NUMERIC',
        );
    } elseif ($max_price > 0) {
        $meta_query[] = array(
            'key' => '_price',
            'value' => $max_price,
            'compare' => '<=',
            'type' => 'NUMERIC',
        );
    }
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $per_page,
        'paged' => $paged,
        'meta_query' => $meta_query,
        'post_status' => 'publish',
        'fields' => 'ids' // Only fetch IDs to improve performance on large lists
    );

    // Taxonomy Query
    if ($cat && $cat !== '0') {
        $field = is_numeric($cat) ? 'term_id' : 'slug'; 

        $args['tax_query'] = array(array(
            'taxonomy' => 'product_cat',
            'field' => $field,
            'terms' => $cat,
        ));
    }

    // Search Keyword
    if (!empty($search_kw)) { 
        $args['s'] = $search_kw; 
    }

    // Allow other plugins/themes to modify query
    $args = apply_filters('mpc_filter_query_args', $args);

    $q = new WP_Query($args);

    ob_start();
    if ($q->have_posts()) {
        
        // Retrieve responsive column settings 
        $data_attrs = '';
        if ($desktop_columns && $tablet_columns && $mobile_columns) {
             $data_attrs = 'data-desktop="'.esc_attr($desktop_columns).'" data-tablet="'.esc_attr($tablet_columns).'" data-mobile="'.esc_attr($mobile_columns).'"';
        }

        // We only show the grid container if this is the first page (paged=1)
        if ($paged === 1) {
            echo '<div id="mpc-grid" class="mpc-grid" '.$data_attrs.'>';
        }

        // Second query to fetch full product objects for template rendering
        $product_ids = $q->posts;
        $product_query = new WP_Query(array(
            'post_type' => 'product',
            'post__in' => $product_ids,
            'orderby' => 'post__in', // Maintain the order from the main filtered query
            'posts_per_page' => -1 
        ));

        while ($product_query->have_posts()) {
            $product_query->the_post();
            global $product;
            $product = wc_get_product(get_the_ID());
            $card_path = MPC_DIR . 'includes/templates/card.php';
            if (file_exists($card_path)) {
                include $card_path;
            } else {
                ?>
                <div class="mpc-card"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
                <?php
            }
        }
        
        if ($paged === 1) {
            echo '</div>'; // Close mpc-grid if it was opened
        }

        wp_reset_postdata(); // Reset main post data

        // Load More Button Logic FIX: Use common nonce, pass essential filters
        if ($q->max_num_pages > $paged) {
            // Collect essential current filter parameters
            $current_filters = array_filter(array(
                'min_price' => $min_price,
                'max_price' => $max_price,
                'product_cat' => $cat, 
                's' => $search_kw,
                'per_page' => $per_page,
                'desktop_columns' => $desktop_columns,
                'tablet_columns' => $tablet_columns,
                'mobile_columns' => $mobile_columns,
            ), function($value) {
                return $value !== null && $value !== '';
            });
            
            // Encode the filter variables to be passed to JS (data-query-vars)
            $query_vars = htmlspecialchars(json_encode($current_filters), ENT_QUOTES, 'UTF-8');

            echo '<div class="mpc-load-more-wrap">
                    <button id="mpc-load-more-btn" class="mpc-load-more-btn" data-query-vars="'.$query_vars.'" data-max-pages="'.$q->max_num_pages.'" data-current-page="'.$paged.'">
                        Load More
                    </button>
                  </div>';
        }
    } else {
        echo '<div class="mpc-no-results">No products found.</div>';
    }

    $html = ob_get_clean();
    // Return only the product cards and the load more button (if any)
    wp_send_json_success(array('html' => $html)); 
}
add_action('wp_ajax_mpc_filter_products', 'mpc_ajax_filter_handler');
add_action('wp_ajax_nopriv_mpc_filter_products', 'mpc_ajax_filter_handler');


/* Top Filter Bar Shortcode - light style */
function mpc_filter_bar_shortcode($atts){
    ob_start();
    // NEW: Get current category slug from URL if on an archive page
    $current_category = '';
    if (is_product_category()) {
        $queried_object = get_queried_object();
        if ($queried_object && isset($queried_object->slug)) {
            $current_category = $queried_object->slug;
        }
    }
    ?>
    <div id="mpc-top-filter-bar" class="mpc-top-filter-bar">
        <?php if ($current_category): ?>
            <input type="hidden" name="current_product_cat" id="mpc-current-cat" value="<?php echo esc_attr($current_category); ?>" />
        <?php endif; ?>
        <div class="mpc-filter-inner">
            <div class="mpc-filter-left">
                <input type="text" id="mpc-search-keyword" placeholder="Search services or products..." aria-label="Search" />
            </div>
            <div class="mpc-filter-center">
                <input type="number" id="mpc-top-min-price" placeholder="Min price" min="0" />
                <input type="number" id="mpc-top-max-price" placeholder="Max price" min="0" />
            </div>
            <div class="mpc-filter-right">
                <button id="mpc-top-apply" class="button">Apply</button>
                <button id="mpc-top-reset" class="button">Reset</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('mpc_filter_bar', 'mpc_filter_bar_shortcode');

/* Ensure the filter-bar javascript & styles are enqueued */
function mpc_filter_bar_assets() {
    // style in main style.css - ensure it's loaded already
    wp_enqueue_script('mpc-filter-bar-js', MPC_URL . 'assets/js/mpc-filter-bar.js', array('jquery','mpc-filters-js'), '1.0', true);
    wp_localize_script('mpc-filter-bar-js', 'mpc_filter_bar_obj', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('mpc_filters_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'mpc_filter_bar_assets', 25);