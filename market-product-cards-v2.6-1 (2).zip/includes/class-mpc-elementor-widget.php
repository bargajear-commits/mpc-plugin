<?php
if (!defined('ABSPATH')) exit;

class MPC_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name(){ return 'mpc_products'; }
    public function get_title(){ return 'MPC Product Cards'; }
    public function get_icon(){ return 'eicon-products'; }
    public function get_categories(){ return ['general']; }
    protected function _register_controls(){
        $this->start_controls_section('content_section', ['label'=>'Content']);
        $this->add_control('per_page', ['label'=>'Products per page','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>8]);
        $this->add_control('columns', ['label'=>'Default Columns (fallback)','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['1'=>1,'2'=>2,'3'=>3,'4'=>4],'default'=>4]);
        $this->add_control('desktop_columns', ['label'=>'Desktop Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['1'=>1,'2'=>2,'3'=>3,'4'=>4],'default'=>4]);
        $this->add_control('tablet_columns', ['label'=>'Tablet Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['1'=>1,'2'=>2,'3'=>3,'4'=>4],'default'=>2]);
        $this->add_control('mobile_columns', ['label'=>'Mobile Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['1'=>1,'2'=>2,'3'=>3],'default'=>1]);
        $this->add_control('query', ['label'=>'Search query','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $this->add_control('cat', ['label'=>'Product category slug (optional)','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $this->end_controls_section();

        $this->start_controls_section('style_section', ['label'=>'Style']);
        $this->add_control('title_color', ['label'=>'Title Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#0b66c3']);
        $this->add_control('button_bg', ['label'=>'Button background','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#0b66c3']);
        $this->add_control('button_text_color', ['label'=>'Button text color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#ffffff']);
        $this->add_control('button_size', ['label'=>'Button font size (px)','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>14]);
        $this->end_controls_section();
    }
    protected function render(){
        $settings = $this->get_settings_for_display();
        $cat = isset($settings['cat']) && $settings['cat'] ? $settings['cat'] : '';
        // pass responsive columns to shortcode
        echo do_shortcode('[mpc_products per_page="'.esc_attr($settings['per_page']).'"
            desktop_columns="'.esc_attr($settings['desktop_columns']).'"
            tablet_columns="'.esc_attr($settings['tablet_columns']).'"
            mobile_columns="'.esc_attr($settings['mobile_columns']).'"
            cat="'.esc_attr($cat).'"
            query="'.esc_attr($settings['query']).'"]');
    }
}
