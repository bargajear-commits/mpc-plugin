<?php
// Expects $product global
$product_id = get_the_ID();
$title = get_the_title($product_id);
$price_html = $product->get_price_html();
$permalink = get_permalink($product_id);
$image = wp_get_attachment_image_src(get_post_thumbnail_id($product_id), 'medium');
$img_tag = $image ? '<img src="'.esc_url($image[0]).'" alt="'.esc_attr($title).'">' : '<div class="mpc-no-image">No image</div>';
$custom = get_post_meta($product_id, 'mpc_custom_field', true);

// rating and sales
$rating = 0;
if (method_exists($product, 'get_average_rating')) {
    $rating = floatval($product->get_average_rating());
}
$total_sales = get_post_meta($product_id, 'total_sales', true);
if ($total_sales === '') $total_sales = 0;

// wishlist button - use host plugin markup if available
$wishlist_button_markup = function_exists('fiverr_wishlist_button') ? fiverr_wishlist_button($product_id) : '<button class="fw-heart-btn" data-product-id="'.esc_attr($product_id).'"><span class="fw-heart-icon">♡</span></button>';

// categories
$cats = get_the_terms($product_id, 'product_cat');
$cat_name = '';
if ($cats && !is_wp_error($cats)){
    $cat_name = $cats[0]->name;
}

// --- UPDATED SELLER INFO ---
// The small, circular image above the product title will now use this URL.
$seller_name = 'marketfastap'; // Updated seller name
$seller_avatar_url = 'https://res.cloudinary.com/dfft01jgi/images/v1757486558/logo_optimized_10-1-1/logo_optimized_10-1-1.png'; // Updated avatar URL
// --- END UPDATED SELLER INFO ---

?>

<div class="mpc-card" data-id="<?php echo esc_attr($product_id); ?>" data-link="<?php echo esc_url($permalink); ?>">
    <a class="mpc-thumb" href="<?php echo esc_url($permalink); ?>">
        <?php echo $img_tag; ?>
    </a>

    <div class="mpc-heart-wrap">
        <?php 
            // output wishlist markup safely
            if (is_string($wishlist_button_markup)) echo $wishlist_button_markup;
            else echo $wishlist_button_markup;
        ?>
    </div>

    <div class="mpc-body">
        
        <!-- SELLER/AVATAR SECTION -->
        <?php if ($seller_name): ?>
        <div class="mpc-seller-info">
            <div class="mpc-avatar">
                <!-- Avatar image with a fallback -->
                <img src="<?php echo esc_url($seller_avatar_url); ?>" alt="<?php echo esc_attr($seller_name); ?> avatar" onerror="this.onerror=null;this.src='https://placehold.co/40x40/dddddd/000000?text=?';">
            </div>
            <span class="mpc-seller-name"><?php echo esc_html($seller_name); ?></span>
        </div>
        <?php endif; ?>
        <!-- END SELLER/AVATAR SECTION -->
        
        <div class="mpc-title-row">
            <h3 class="mpc-title"><a href="<?php echo esc_url($permalink); ?>"><?php echo esc_html($title); ?></a></h3>
            <button class="mpc-share-trigger" data-id="<?php echo esc_attr($product_id); ?>" data-link="<?php echo esc_url($permalink); ?>" aria-label="Share">🔗</button>
        </div>
        <?php if ($custom): ?>
            <div class="mpc-custom"><?php echo esc_html($custom); ?></div>
        <?php endif; ?>
        <div class="mpc-meta">
            <div class="mpc-price">From <?php echo $price_html; ?></div>
            <?php if ($cat_name): ?>
                <div class="mpc-cat"><?php echo esc_html($cat_name); ?></div>
            <?php endif; ?>
        </div>

        <div class="mpc-extra">
            <?php if ($rating > 0): ?>
                <div class="mpc-rating-sales">
                    <span class="mpc-star">★</span> 
                    <span class="mpc-rating-value"><?php echo number_format($rating, 1); ?></span>
                    <?php if ($total_sales > 0): ?>
                        <span class="mpc-sales-count">(<?php echo esc_html($total_sales); ?>)</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        
    </div>
</div>
