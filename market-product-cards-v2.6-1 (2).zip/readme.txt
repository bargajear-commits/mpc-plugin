Market Product Cards v2.4 - Responsive Elementor controls (desktop/tablet/mobile columns), refined UI/UX, wishlist integration, share modal, rating and sales count.
Shortcode: [mpc_products per_page="8" desktop_columns="4" tablet_columns="2" mobile_columns="1"]
