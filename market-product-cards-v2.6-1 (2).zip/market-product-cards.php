<?php
/**
 * Plugin Name: Market Product Cards (v2.5)
 * Description: WooCommerce product cards with Elementor widget, wishlist integration, share modal, category badge, rating and sales count. Responsive controls for desktop/tablet/mobile columns. Now with Archive page integration and AJAX Load More.
 * Version: 2.5
 * Author: Rivalinks + ChatGPT + Gemini
 */

if (!defined('ABSPATH')) exit;

define('MPC_DIR', plugin_dir_path(__FILE__));
define('MPC_URL', plugin_dir_url(__FILE__));


/* Enqueue assets */
function mpc_enqueue_assets(){
	wp_enqueue_style('mpc-style', MPC_URL . 'assets/css/style.css', [], '2.5');
	wp_enqueue_script('mpc-share', MPC_URL . 'assets/js/share.js', ['jquery'], '2.5', true);
	wp_enqueue_script('mpc-responsive', MPC_URL . 'assets/js/responsive.js', ['jquery'], '2.5', true);
	
	// Enqueue new script for AJAX load more and localize data
	wp_enqueue_script('mpc-ajax-load-more', MPC_URL . 'assets/js/ajax-load-more.js', ['jquery'], '2.5', true);
	wp_localize_script('mpc-ajax-load-more', 'mpc_ajax', [
		'ajax_url' => admin_url('admin-ajax.php'),
		// FIX: Use 'mpc_filters_nonce' as the common nonce for all AJAX, since filter handler uses it.
		'nonce'	   => wp_create_nonce('mpc_filters_nonce') 
	]);
}
add_action('wp_enqueue_scripts', 'mpc_enqueue_assets', 20); 

// ...

/* Add custom product field */
add_action('woocommerce_product_options_general_product_data', 'mpc_add_custom_field');
function mpc_add_custom_field(){
	woocommerce_wp_text_input([
		'id' => 'mpc_custom_field',
		'label' => __('MPC Custom Field', 'mpc'),
		'desc_tip' => 'true',
		'description' => 'Shown on product card.',
	]);
}
add_action('woocommerce_process_product_meta', 'mpc_save_custom_field');
function mpc_save_custom_field($post_id){
	$val = isset($_POST['mpc_custom_field']) ? sanitize_text_field($_POST['mpc_custom_field']) : '';
	update_post_meta($post_id, 'mpc_custom_field', $val);
}

/*
 * Advanced Query Analysis Helper
 * Detects search query, categories, tags, and other taxonomies from the current page context.
 */
function mpc_build_query_args_from_context($atts) {
	global $wp_query;
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

	$args = [
		'post_type'	   => 'product',
		'posts_per_page' => intval($atts['per_page']),
		'paged'			 => $paged,
		'orderby'		 => $atts['orderby'],
		'order'			 => $atts['order'],
	];

	// Merge with the main query to respect all filters (search, category, tags, etc.)
	// This is the key for advanced URL analysis.
	if (is_main_query() && (is_shop() || is_product_category() || is_product_tag() || is_search())) {
		$args = array_merge($wp_query->query_vars, $args);
		// Ensure posts_per_page from shortcode is respected
		$args['posts_per_page'] = intval($atts['per_page']);
	} else {
		// Fallback for manual shortcode usage
		if (!empty($atts['cat'])) {
			$args['tax_query'][] = [
				'taxonomy' => 'product_cat',
				'field'	   => 'slug',
				'terms'	   => sanitize_text_field($atts['cat']),
			];
		}
		if (!empty($atts['query'])) {
			$args['s'] = sanitize_text_field($atts['query']);
		}
	}
	
	// Remove potential conflicts
	unset($args['error']);
	unset($args['m']);
	unset($args['p']);
	unset($args['post_parent']);
	unset($args['subpost']);
	unset($args['subpost_id']);
	unset($args['attachment']);
	unset($args['attachment_id']);
	unset($args['name']);
	unset($args['static']);
	unset($args['pagename']);
	unset($args['page_id']);
	unset($args['second']);
	unset($args['minute']);
	unset($args['hour']);
	unset($args['day']);
	unset($args['monthnum']);
	unset($args['year']);
	unset($args['w']);
	unset($args['category_name']);
	unset($args['tag']);
	unset($args['author_name']);

	return $args;
}


/* Core Product Loop Function */
function mpc_products_loop($atts) {
	if (!class_exists('WooCommerce')) return '<p>WooCommerce required.</p>';

	$a = shortcode_atts([
		'per_page'		  => 8,
		'columns'		   => 4, // Fallback
		'desktop_columns' => 4,
		'tablet_columns'  => 2,
		'mobile_columns'  => 1,
		'orderby'		   => 'date',
		'order'			 => 'DESC',
		'cat'			   => '', // For manual shortcode
		'query'			 => '', // For manual shortcode
	], $atts);

	$args = mpc_build_query_args_from_context($a);
	$loop = new WP_Query($args);
	
	ob_start();

	// Pass query and settings to frontend for AJAX
	$query_vars = htmlspecialchars(json_encode($args), ENT_QUOTES, 'UTF-8');
	
	$data_attrs = 'data-desktop="'.intval($a['desktop_columns']).'" data-tablet="'.intval($a['tablet_columns']).'" data-mobile="'.intval($a['mobile_columns']).'"';
	
	echo '<div id="mpc-product-container">';
	echo '<div id="mpc-grid" class="mpc-grid" '.$data_attrs.'>';
	
	if ($loop->have_posts()){
		while ($loop->have_posts()){
			$loop->the_post();
			global $product;
			include MPC_DIR . 'includes/templates/card.php';
		}
	} else {
		if (!isset($_POST['page'])) { // Show "no products" only on initial load
			echo '<p class="mpc-no-products">No products found.</p>';
		}
	}
	
	echo '</div>';
	
	// Load More Button
	if ($loop->max_num_pages > 1) {
		echo '<div class="mpc-load-more-wrap">
				<button id="mpc-load-more-btn" class="mpc-load-more-btn" data-query-vars="'.$query_vars.'" data-max-pages="'.$loop->max_num_pages.'" data-current-page="1">
					Load More
				</button>
			  </div>';
	}
	
	echo '</div>'; // End #mpc-product-container
	
	// Share Modal (only output once)
	if (!isset($_POST['page'])) {
		echo '<div id="mpc-share-modal" class="mpc-share-modal" aria-hidden="true">
			<div class="mpc-share-inner">
			<!-- Removed: Close button HTML block -->
				<h4 class="mpc-share-title">Share this product</h4>
				<p class="mpc-share-subtitle">Spread the word!</p>
				<div class="mpc-share-buttons-grid">
					<a href="#" class="mpc-share-btn mpc-share-whatsapp" target="_blank" rel="noopener" aria-label="Share on WhatsApp">
						<span class="share-icon whatsapp-icon"></span>
						<span class="share-text">WhatsApp</span>
					</a>
					<a href="#" class="mpc-share-btn mpc-share-facebook" target="_blank" rel="noopener" aria-label="Share on Facebook">
						<span class="share-icon facebook-icon"></span>
						<span class="share-text">Facebook</span>
					</a>
					<a href="#" class="mpc-share-btn mpc-share-x" target="_blank" rel="noopener" aria-label="Share on X / Twitter">
						<span class="share-icon x-icon"></span>
						<span class="share-text">X / Twitter</span>
					</a>
				</div>
				
				<div class="mpc-copy-link-wrapper">
					<span class="copy-icon"></span>
					<button class="mpc-share-copy">Copy Product Link</button>
				</div>
			</div>
		</div>';
	}

	wp_reset_postdata();
	return ob_get_clean();
}
add_shortcode('mpc_products', 'mpc_products_loop');

/* AJAX handler for loading more products */
function mpc_load_more_products_ajax() {
	check_ajax_referer('mpc-load-more-nonce', 'nonce');

	$args = json_decode(stripslashes($_POST['query_vars']), true);
	$args['paged'] = intval($_POST['page']);
	$args['post_status'] = 'publish';

	$loop = new WP_Query($args);

	if ($loop->have_posts()) {
		while ($loop->have_posts()) {
			$loop->the_post();
			global $product;
			include MPC_DIR . 'includes/templates/card.php';
		}
	}
	wp_die();
}
add_action('wp_ajax_mpc_load_more', 'mpc_load_more_products_ajax');
add_action('wp_ajax_nopriv_mpc_load_more', 'mpc_load_more_products_ajax');


/* Elementor integration */
function mpc_register_elementor_widget(){
	if (!did_action('elementor/loaded')) return;
	require_once MPC_DIR . 'includes/class-mpc-elementor-widget.php';
	\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \MPC_Elementor_Widget());
}
add_action('elementor/widgets/widgets_registered', 'mpc_register_elementor_widget');

/*
 * WooCommerce Archive Page Integration
 * This replaces the default WooCommerce loop with our custom card loop.
 */
function mpc_override_woo_archives() {
	// Only run on WooCommerce archive pages
	if ( (is_shop() || is_product_category() || is_product_tag() || is_tax(get_object_taxonomies('product'))) && !is_admin() ) {
		
		// Remove default WC content wrappers and loop
		remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
		remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
		remove_action('woocommerce_before_shop_loop', 'woocommerce_output_all_notices', 10);
		remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
		remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);
		remove_action('woocommerce_shop_loop', 'woocommerce_product_loop_start', 5);
		remove_action('woocommerce_shop_loop', 'woocommerce_product_loop_end', 5);
		remove_action('woocommerce_shop_loop', 'woocommerce_pagination', 10);

		// Add our custom loop
		add_action('woocommerce_shop_loop', function() {
			// Get products per page from WooCommerce settings
			$per_page = get_option('posts_per_page');
			echo mpc_products_loop(['per_page' => $per_page]);
		});
	}
}
add_action('template_redirect', 'mpc_override_woo_archives');

require_once MPC_DIR . 'includes/mpc-filters.php';
